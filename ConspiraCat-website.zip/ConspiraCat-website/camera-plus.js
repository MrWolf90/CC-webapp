/* ConspiraCat (web) camera upgrade. (c) 2026 A.A. All rights reserved.
   Adds to the QR scanner: sharper camera picture, zoom (pinch, buttons, slider, double-tap),
   tap to focus, torch, full-screen view and a green highlight when a code is found.
   Works with the phone's real optical/digital zoom when the browser allows it,
   otherwise with a sharp crop of the full-resolution picture. */
(function () {
  'use strict';
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;

  var S = { stream: null, track: null, caps: {}, hw: false, zMin: 1, zMax: 4, zoom: 1, dz: 1, torch: false, ui: null, found: false };
  var $ = function (id) { return document.getElementById(id); };
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var fmt = function (z) { return (Math.abs(z - Math.round(z)) < 0.05 ? String(Math.round(z)) : z.toFixed(1)) + '×'; };

  // 1) Ask for a sharper picture with continuous autofocus.
  var origGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  navigator.mediaDevices.getUserMedia = function (c) {
    var original = c;
    var isVideo = c && c.video;
    if (isVideo) {
      var v = typeof c.video === 'object' ? Object.assign({}, c.video) : {};
      v.width = { ideal: 1920 }; v.height = { ideal: 1080 };
      v.advanced = (v.advanced || []).concat([{ focusMode: 'continuous' }]);
      c = Object.assign({}, c, { video: v });
    }
    return origGUM(c).catch(function (err) {
      // Some phones refuse the bigger size: fall back to what the app asked for.
      if (isVideo && err && (err.name === 'OverconstrainedError' || err.name === 'ConstraintNotSatisfiedError')) return origGUM(original);
      throw err;
    }).then(function (stream) {
      if (isVideo) setTimeout(function () { onStream(stream); }, 0);
      return stream;
    });
  };

  // 2) Decode exactly what's visible (and zoomed) in the viewfinder, at full camera resolution.
  var origDraw = CanvasRenderingContext2D.prototype.drawImage;
  CanvasRenderingContext2D.prototype.drawImage = function (img) {
    if (img && img.id === 'video' && arguments.length === 9 && img.videoWidth) {
      var vw = img.videoWidth, vh = img.videoHeight, box = img.parentNode.getBoundingClientRect();
      if (box.width > 0 && box.height > 0) {
        var s = Math.max(box.width / vw, box.height / vh);
        var side = Math.min(box.width, box.height) / s / S.dz;
        side = Math.min(side, vw, vh);
        return origDraw.call(this, img, (vw - side) / 2, (vh - side) / 2, side, side,
          arguments[5], arguments[6], arguments[7], arguments[8]);
      }
    }
    return origDraw.apply(this, arguments);
  };

  // 3) Notice when the QR worker finds a code, to show the green box.
  var OrigWorker = window.Worker;
  if (OrigWorker) {
    var W = function (url, opts) {
      var w = new OrigWorker(url, opts);
      if (String(url).indexOf('qr-worker') === -1) return w;
      // Hold the "found" answer for a moment so the green box is visible before the result opens.
      var lastFound = 0;
      var relay = function (fn, ctx, e) {
        if (e.data && e.data.text) {
          var now = Date.now();
          if (now - lastFound < 1500) return; // same code seen again while waiting: ignore
          lastFound = now;
          onFound(e.data);
          setTimeout(function () { fn.call(ctx, e); }, 450);
        } else fn.call(ctx, e);
      };
      var add = w.addEventListener.bind(w);
      w.addEventListener = function (type, fn, o) {
        if (type === 'message' && typeof fn === 'function') {
          var f = fn; fn = function (e) { relay(f, w, e); };
        }
        return add(type, fn, o);
      };
      var handler = null;
      add('message', function (e) { if (handler) relay(handler, w, e); });
      Object.defineProperty(w, 'onmessage', { configurable: true, get: function () { return handler; }, set: function (fn) { handler = fn; } });
      return w;
    };
    W.prototype = OrigWorker.prototype;
    window.Worker = W;
  }

  function onStream(stream) {
    var track = stream.getVideoTracks()[0];
    if (!track) return;
    S.stream = stream; S.track = track; S.found = false; S.torch = false;
    S.caps = (track.getCapabilities && track.getCapabilities()) || {};
    S.hw = !!(S.caps.zoom && S.caps.zoom.max > S.caps.zoom.min);
    S.zMin = S.hw ? S.caps.zoom.min : 1;
    S.zMax = S.hw ? Math.min(S.caps.zoom.max, 10) : 4;
    var cur = S.hw && track.getSettings ? (track.getSettings().zoom || S.zMin) : 1;
    S.zoom = cur; S.dz = 1;
    var video = $('video'); if (video) video.style.transform = '';
    buildUI();
    updateUI();
  }

  function setZoom(z, quiet) {
    z = clamp(z, S.zMin, S.zMax);
    S.zoom = z;
    if (S.hw && S.track) {
      S.dz = 1;
      try { S.track.applyConstraints({ advanced: [{ zoom: z }] }).catch(function () {}); } catch (e) {}
    } else {
      S.dz = z;
      var video = $('video'); if (video) video.style.transform = z > 1.001 ? 'scale(' + z + ')' : '';
    }
    updateUI();
    if (!quiet) bubble();
  }

  function focusAt(x, y) {
    var vf = $('viewfinder'); if (!vf || !S.track) return;
    var r = vf.getBoundingClientRect();
    var ring = document.createElement('div');
    ring.className = 'cp-focus';
    ring.style.left = (x - r.left) + 'px'; ring.style.top = (y - r.top) + 'px';
    vf.appendChild(ring);
    setTimeout(function () { ring.remove(); }, 1100);
    var fm = S.caps.focusMode || [];
    var adv = { pointsOfInterest: [{ x: clamp((x - r.left) / r.width, 0, 1), y: clamp((y - r.top) / r.height, 0, 1) }] };
    if (fm.indexOf('single-shot') !== -1) adv.focusMode = 'single-shot';
    try {
      S.track.applyConstraints({ advanced: [adv] }).then(function () {
        if (fm.indexOf('continuous') !== -1) setTimeout(function () {
          try { S.track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function () {}); } catch (e) {}
        }, 3000);
      }).catch(function () {});
    } catch (e) {}
  }

  function toggleTorch() {
    if (!S.track || !S.caps.torch) return;
    S.torch = !S.torch;
    try { S.track.applyConstraints({ advanced: [{ torch: S.torch }] }).catch(function () { S.torch = false; updateUI(); }); } catch (e) {}
    updateUI();
  }

  function toggleFull(force) {
    var vf = $('viewfinder'); if (!vf) return;
    var on = typeof force === 'boolean' ? force : !vf.classList.contains('cp-full');
    vf.classList.toggle('cp-full', on);
    document.documentElement.classList.toggle('cp-noscroll', on);
    updateUI();
  }

  var bubbleT = null;
  function bubble() {
    var b = S.ui && S.ui.querySelector('.cp-bubble'); if (!b) return;
    b.textContent = fmt(S.zoom); b.classList.add('on');
    clearTimeout(bubbleT); bubbleT = setTimeout(function () { b.classList.remove('on'); }, 1000);
  }

  function stops() {
    var out = [];
    if (S.zMin < 0.95) out.push(Math.max(S.zMin, 0.5));
    out.push(Math.max(1, S.zMin));
    [2, 3, 5, 10].forEach(function (z) { if (S.zMax >= z) out.push(z); });
    return out;
  }

  function buildUI() {
    var vf = $('viewfinder'); if (!vf) return;
    if (S.ui && S.ui.parentNode === vf) return;
    var ui = document.createElement('div');
    ui.className = 'cp-ui';
    ui.innerHTML =
      '<div class="cp-pill" role="status"><i></i><span>Looking for QR codes…</span></div>' +
      '<div class="cp-box" aria-hidden="true"></div>' +
      '<div class="cp-bubble" aria-hidden="true"></div>' +
      '<div class="cp-side">' +
        '<button type="button" class="cp-btn cp-torch" aria-label="Light">' +
          '<svg viewBox="0 0 24 24"><path d="M7 2h10v4l-3 4v12h-4V10L7 6V2Z"/></svg></button>' +
        '<button type="button" class="cp-btn cp-fs" aria-label="Full screen">' +
          '<svg viewBox="0 0 24 24"><path class="cp-fs-open" d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/><path class="cp-fs-close" d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg></button>' +
      '</div>' +
      '<div class="cp-bottom">' +
        '<div class="cp-chips"></div>' +
        '<input class="cp-slider" type="range" min="0" max="1000" value="0" aria-label="Zoom">' +
        '<div class="cp-tip">Pinch to zoom · tap to focus · double-tap for 2×</div>' +
      '</div>';
    vf.appendChild(ui);
    S.ui = ui;

    ui.querySelector('.cp-torch').addEventListener('click', function (e) { e.stopPropagation(); toggleTorch(); });
    ui.querySelector('.cp-fs').addEventListener('click', function (e) { e.stopPropagation(); toggleFull(); });
    var slider = ui.querySelector('.cp-slider');
    slider.addEventListener('input', function () {
      // logarithmic feel, like phone cameras
      var t = slider.value / 1000;
      setZoom(S.zMin * Math.pow(S.zMax / S.zMin, t));
    });
    ['pointerdown', 'touchstart', 'click', 'dblclick'].forEach(function (ev) {
      ui.querySelector('.cp-bottom').addEventListener(ev, function (e) { e.stopPropagation(); }, { passive: true });
    });

    // Gestures on the picture: pinch, tap, double-tap.
    var pinch = null, lastTap = 0, tapT = null, moved = false;
    var dist = function (t) { return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); };
    vf.addEventListener('touchstart', function (e) {
      if (!vf.classList.contains('live')) return;
      if (e.touches.length === 2) { pinch = { d: dist(e.touches), z: S.zoom }; moved = true; }
      else moved = false;
    }, { passive: true });
    vf.addEventListener('touchmove', function (e) {
      if (pinch && e.touches.length === 2) {
        e.preventDefault();
        setZoom(pinch.z * dist(e.touches) / pinch.d);
      } else moved = true;
    }, { passive: false });
    vf.addEventListener('touchend', function (e) { if (e.touches.length < 2) pinch = null; }, { passive: true });
    vf.addEventListener('click', function (e) {
      if (!vf.classList.contains('live') || moved) return;
      if (e.target.closest && e.target.closest('.cp-btn, .cp-bottom, .cam-off')) return;
      var now = Date.now(), x = e.clientX, y = e.clientY;
      if (now - lastTap < 300) {
        clearTimeout(tapT); lastTap = 0;
        setZoom(S.zoom < 1.5 ? 2 : Math.max(1, S.zMin));
      } else {
        lastTap = now;
        tapT = setTimeout(function () { focusAt(x, y); }, 280);
      }
    });
    // Mouse wheel / trackpad zoom on computers
    vf.addEventListener('wheel', function (e) {
      if (!vf.classList.contains('live')) return;
      e.preventDefault();
      setZoom(S.zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1));
    }, { passive: false });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') toggleFull(false); });
  }

  function updateUI() {
    var ui = S.ui; if (!ui) return;
    var chips = ui.querySelector('.cp-chips');
    var st = stops();
    var active = 0;
    st.forEach(function (z, i) { if (Math.abs(z - S.zoom) < Math.abs(st[active] - S.zoom)) active = i; });
    chips.innerHTML = '';
    st.forEach(function (z, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'cp-chip' + (i === active ? ' on' : '');
      b.textContent = i === active ? fmt(S.zoom) : fmt(z).replace('×', '');
      b.setAttribute('aria-label', 'Zoom ' + fmt(z));
      b.addEventListener('click', function (e) { e.stopPropagation(); setZoom(z); });
      chips.appendChild(b);
    });
    var slider = ui.querySelector('.cp-slider');
    slider.value = String(Math.round(1000 * Math.log(S.zoom / S.zMin) / Math.log(S.zMax / S.zMin || 2)));
    var torch = ui.querySelector('.cp-torch');
    torch.hidden = !S.caps.torch;
    torch.classList.toggle('on', S.torch);
    var vf = $('viewfinder');
    ui.querySelector('.cp-fs').classList.toggle('on', !!(vf && vf.classList.contains('cp-full')));
    ui.classList.toggle('found', S.found);
    var pill = ui.querySelector('.cp-pill span');
    pill.textContent = S.found ? 'QR code found' : 'Looking for QR codes…';
  }

  function onFound(d) {
    if (!S.ui) return;
    S.found = true;
    try { if (navigator.vibrate) navigator.vibrate(40); } catch (e) {}
    var box = S.ui.querySelector('.cp-box');
    var vf = $('viewfinder');
    if (d.loc && d.size && vf) {
      // the decoded square is the centred square of the viewfinder
      var r = vf.getBoundingClientRect(), side = Math.min(r.width, r.height);
      var ox = (r.width - side) / 2, oy = (r.height - side) / 2, k = side / d.size;
      var xs = d.loc.map(function (p) { return ox + p.x * k; }), ys = d.loc.map(function (p) { return oy + p.y * k; });
      var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
      var pad = 8;
      box.style.left = (x0 - pad) + 'px'; box.style.top = (y0 - pad) + 'px';
      box.style.width = (x1 - x0 + 2 * pad) + 'px'; box.style.height = (y1 - y0 + 2 * pad) + 'px';
      box.classList.add('on');
    }
    updateUI();
    setTimeout(function () {
      S.found = false; box.classList.remove('on'); toggleFull(false); updateUI();
    }, 1200);
  }

  // Leaving the scan screen / camera stopped: reset zoom & light, leave full screen.
  setInterval(function () {
    if (S.stream && !S.stream.active) {
      S.stream = null; S.track = null; S.torch = false; S.dz = 1;
      var video = $('video'); if (video) video.style.transform = '';
      toggleFull(false);
    }
  }, 700);
})();
