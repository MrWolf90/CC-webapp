/* ConspiraCat QR decoding worker. Uses jsQR (Apache License 2.0, see lib/LICENSE-jsQR.txt).
   When the browser has a built-in barcode detector (Chrome on Android), it is used first:
   it is faster and reads small, tilted, blurry or damaged codes much better. */
importScripts('lib/jsQR.js');
var detector = null;
try {
  if (typeof BarcodeDetector !== 'undefined') detector = new BarcodeDetector({ formats: ['qr_code'] });
} catch (e) { detector = null; }

function viaJsQR(d) {
  var r = null;
  try { r = jsQR(new Uint8ClampedArray(d.data), d.w, d.h, { inversionAttempts: d.invert ? 'attemptBoth' : 'dontInvert' }); } catch (err) { r = null; }
  if (!r) return { text: null };
  var L = r.location;
  return { text: r.data, size: d.w, loc: [L.topLeftCorner, L.topRightCorner, L.bottomRightCorner, L.bottomLeftCorner] };
}

self.onmessage = function (e) {
  var d = e.data;
  if (!detector) { self.postMessage(viaJsQR(d)); return; }
  var img;
  try { img = new ImageData(new Uint8ClampedArray(d.data), d.w, d.h); } catch (err) { self.postMessage(viaJsQR(d)); return; }
  detector.detect(img).then(function (codes) {
    var c = codes && codes.find(function (x) { return x.rawValue; });
    if (c) self.postMessage({ text: c.rawValue, size: d.w, loc: c.cornerPoints || [] });
    else self.postMessage(viaJsQR(d));
  }).catch(function () { detector = null; self.postMessage(viaJsQR(d)); });
};
