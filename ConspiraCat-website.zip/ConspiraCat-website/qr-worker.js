/* ConspiraCat QR decoding worker. Uses jsQR (Apache License 2.0, see lib/LICENSE-jsQR.txt). */
importScripts('lib/jsQR.js');
self.onmessage = function (e) {
  var d = e.data, r = null;
  try { r = jsQR(new Uint8ClampedArray(d.data), d.w, d.h, { inversionAttempts: d.invert ? 'attemptBoth' : 'dontInvert' }); } catch (err) { r = null; }
  self.postMessage({ text: r ? r.data : null });
};
